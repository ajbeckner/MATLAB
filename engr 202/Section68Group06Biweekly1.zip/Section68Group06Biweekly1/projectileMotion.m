function [ posx, posy ] = projectileMotion( angle, velocity )
%Function animates balls projectile motion based of user input launch angle
%and launch velocity.

figure(1) % Creates a figure
axis([0 45 0 45]); %Sets figure to 100x100
hold on

tsteps = 200; %Defines the amount of times position will be calculated
t = linspace(0,8,tsteps); %Generates 200 points between 0 and 8
g = -9.8; %Defines gravitational acceleration
radius = 1; %Defines radius of ball
pradius = .1; %Defines radius of path

ballX = radius*sin(-pi:0.1*pi:pi); %Parameters for ball x values
ballY = radius*cos(-pi:0.1*pi:pi); %Parameters for ball y values
pathX = pradius*sin(-pi:0.1*pi:pi); %Parameters for path x values
pathY = pradius*cos(-pi:0.1*pi:pi); %Parameters for path y values

for i=1:tsteps
    
    posX = (velocity*cos(pi*(angle/180)))*t; %X position equation
    posY = (g/2)*t.^2+(velocity*sin(pi*(angle/180)))*t; %Y position equation
    stop = posY(i); %Defines stop variable (used to stop animation when ball hits ground
    
    if stop >= -2 %Determines when to animate ball and trail, -2 because staring postition of the ball is 2 above x-axis
        ball = fill(ballX+posX(i), ballY+posY(i)+2, 'r'); %Animates ball 
        trail = fill(pathX+posX(i), pathY+posY(i)+2, 'k'); %Animates trail
        hold on %Allows the figure to take multiple inputs
        pause(.000001) %Pauses code before each run
        delete(ball) %Deletes ball from figure
    elseif stop < -2 %Determines when to stop ball
        ball = fill(ballX+posX(i), ballY+posY(i)+2, 'r'); %Displays ball final position
        trail = fill(pathX+posX(i), pathY+posY(i)+2, 'k'); %Displays trail final position
        break %breaks the loop
    end
end
end

