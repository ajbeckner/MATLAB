function [changeX,changeY] = takeStep( dimensions )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

if nargin == 0
    dimensions = 1;
end

changeX = 0;
changeY = 0;

s = rand - .5;
if s == 0
    takeStep(dimensions);
elseif s < 0
    changeX = -1;
elseif s > 0
    changeX = 1;
end

if dimensions == 2
    xory = rand - .5;
    if xory == 0
        takeStep(dimensions);
    elseif xory < 0
        changeY = 0;
    elseif xory > 0
        changeY = changeX;
        changeX = 0;
    end
    
end

if dimensions ~= 1 && dimensions ~= 2
    fprintf('error in function takeStep: invalid input');
end
end

