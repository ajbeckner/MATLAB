%% Basics: Question 1

%get rid of everything in the workspace and command window
clear all;close all;clc;
fprintf('Problem 1: \n')
%create random vector with 1000 numbers between 0.5 and 1
myVector = rand(1000,1); 

%create matrix that has 1's for the numbers above .5
greaterVector = myVector > 0.5;
countGreaterVector = sum(greaterVector);%sum of the 1's to get the count
fprintf('The vector has %g values < 0.5 \n', countGreaterVector) %print to show the count

%create matrix that has 1's for the numbers between .3 and .7
rangeVector = (myVector > 0.3 & myVector < 0.7);
countRangeVector = sum(rangeVector);%sum of the 1's to get the count
fprintf('The Vector has %g values between 0.3 and 0.7. \n', countRangeVector) %print to show the count

%create histogram to show distribution of the variables 
figure(1)
hist(myVector, 10) 
%formatting
hold on
grid on
title('Distribution of random variables')
xlabel('Bin')
ylabel('Frequency')

%Calculate and print std and mean with inbuilt functions
AverageMyVector = mean(myVector);
StdMyVector = std(myVector);
fprintf('The mean of the vector is %g \n', AverageMyVector)
fprintf('The std of the vector is %g \n\n', StdMyVector)
 
%% Random Walk
%% Question 2 - one dimensional walk
fprintf('Problem 2: \n')

%create matrix to hold 25 steps + original position
positionMatrix = zeros(1,26);

%save first location at the origin
position = 0;
positionMatrix(1) = position;

%set max at zero to start
max = 0;

%for loop that iterates to number of steps
for i = (2:1:length(positionMatrix))
    
    %calls function to take step and adds to current position
    s = takeStep;
    position = position + s;
    
    %saves position in matrix with index
    positionMatrix(i) = position;
    
    %updates max if necessary
    if abs(position) > max
        max = abs(position);
    end
    
end
%prints final max value
fprintf('The maximum distance was %g units\n\n',max);

%creates figure with plot of movement
%formatting
figure(2);
hold on
title('Movement of Particle');
xlabel('Time')
ylabel('Position')
%plot of positions from matrix
plot((1:26),positionMatrix,'o:')

%% Question 3 - two dimensional walk
fprintf('Problem 3: \n')

%create matrix to hold 25 steps + original position

positionMatrix = zeros(2,26);

%save first location at the origin
position = [0;0];
positionMatrix(:,1) = position;

%set max at zero to start
max = 0;

%for loop that iterates to number of steps
for i = (2:1:length(positionMatrix))
    
    %calls function to take step and adds to current position, now with 2
    %variables
    [x,y] = takeStep(2);
    position = position + [x;y];
    
    %saves position in matrix with index
    positionMatrix(:,i) = position;
    
    %updates max when necessary using distance formula
    if sqrt(position(1)^2 + position(2)^2) > max
        max = sqrt(position(1)^2 + position(2)^2);
    end
end

%print final max value
fprintf('The maximum distance was %g units\n\n',max);

%create figure tracing 2d path of particla
%formatting
figure(3);
hold on
title('Path of Particle');
xlabel('x position')
ylabel('y position')
%plot path
plot(positionMatrix(1,:),positionMatrix(2,:))
%plot markers at beginning and end of path
plot(positionMatrix(1,1),positionMatrix(2,1),'go','MarkerSize',20)
plot(positionMatrix(1,length(positionMatrix)),positionMatrix(2,length(positionMatrix)),'ro','MarkerSize',20);

%% Question 4a
fprintf('Problem 4: \n')

% %initialize array to keep track of the trials
% stepCounts = zeros(1,5000);
% 
% %for loop that iterates over 5000 trials
% for i = 1:1:5000
%  
%     %initialize counter
%     stepCount = 0;
%     
%     %set initial positions randomly
%     person1 = [round(50*(rand-.5));round(50*(rand-.5))];
%     person2 = [round(50*(rand-.5));round(50*(rand-.5))];
%     
%     %check distance of original positions
%     distance = sqrt((person1(1) - person2(1))^2+(person1(2) - person2(2))^2);
% 
%     %while loop operates as long as distance is not 5 or less
%     while distance > 5
%         %uses function to tke step, adds to position 
%         [x,y] = takeStep(2);
%         newperson1 = person1 + [x;y];
%         %loop forces redo if person has stepped out of bounds (greater abs than
%         %50)
%         while (abs(newperson1(1)) > 50 || abs(newperson1(2)) > 50)
%             [x,y] = takeStep(2);
%             newperson1 = person1 + [x;y];
%         end
%         %stores result of original trial (or redo)
%         person1 = newperson1;
%         
%         %uses function to tke step, adds to position 
%         [x,y] = takeStep(2);
%         newperson2 = person2 + [x;y];
%         %loop forces redo if person has stepped out of bounds (greater abs than
%         %50)
%         while (abs(newperson2(1)) > 50 || abs(newperson2(2)) > 50)
%             [x,y] = takeStep(2);
%             newperson2 = person2 + [x;y];
%         end
%         %stores result of original trial (or redo)
%         person2 = newperson2;
%         
%         %checks distance and adds to running count of steps 
%         stepCount = stepCount + 1;
%         distance = sqrt((person1(1) - person2(1))^2+(person1(2) - person2(2))^2);
%     end
%     %add stepcount to matrix for histogram later
%     stepCounts(1,i) = stepCount;
% 
% end
% 
% %print average number of steps
% fprintf('The average steps in experiment 1 was: %d.\n',mean(stepCounts));
% 
% %make histogram of distribution of stepcounts
% %formatting
% figure(4);
% hold on;
% grid on;
% title('Distribution of Steps');
% xlabel('Steps');
% ylabel('Frequency');
% %plot hist
% hist(stepCounts);

%print result from trials run in class
fprintf('The average steps in experiment 1 was: %d.\n',7592);

%% Question 4b

% %initialize array to keep track of the trials
% stepCounts = zeros(1,5000);
% 
% %for loop that iterates over 5000 trials
% for i = 1:1:5000
%     
%     %initialize counter
%     stepCount = 0;
%     
%     %set initial positions randomly
%     person1 = [round(50*(rand-.5));round(50*(rand-.5))];
%     person2 = [round(50*(rand-.5));round(50*(rand-.5))];
%     
%     %check distance
%     distance = sqrt((person1(1) - person2(1))^2+(person1(2) - person2(2))^2);
% 
%     %while loop operates as long as distance is not 5 or less
%     while distance > 5
%         
%         %uses function to tke step, adds to position 
%         [x,y] = takeStep(2);
%         newperson1 = person1 + [x;y];
%         %loop forces redo if person has stepped out of bounds (greater abs than
%         %50)
%         while (abs(newperson1(1)) > 50 || abs(newperson1(2)) > 50)
%             [x,y] = takeStep(2);
%             newperson1 = person1 + [x;y];
%         end
%         %stores result of original trial (or redo)
%         person1 = newperson1;        
%         
%         %checks distance and adds to running count of steps 
%         stepCount = stepCount + 1;
%         distance = sqrt((person1(1) - person2(1))^2+(person1(2) - person2(2))^2);
%     end
% 
%     %add stepcount to matrix for histogram later
%     stepCounts(1,i) = stepCount;
% end
% 
% %print average number of steps
% fprintf('The average steps in experiment 2 was: %d.\n',mean(stepCounts));
% 
% %make histogram of distribution of stepcounts
% %formatting
% figure(5);
% hold on;
% grid on;
% title('Distribution of Steps (with one still)');
% xlabel('Steps');
% ylabel('Frequency');
% %plot hist
% hist(stepCounts);

%print result from trials run in class
fprintf('The average steps in experiment 2 was: %d.\n\n',11178);

%% Projectile Motion

angle = input('Enter launch angle: '); %Prompts user to enter launch angle

%Makes sure the user enters an angle between 0 and 90 degrees
while angle < 0 || angle > 90 
    angle = input('Enter launch angle between 0 and 90 degrees: '); %Prompts the user to reenter an angle in the correct range
end


velocity = input('Enter launch velocity: '); %Prompts user to enter launch velocity

%Makes sure user enters velocity between 0 and 20 m/s
while velocity < 0 || velocity > 20 
    velocity = input('Enter launch velocity between 0 m/s and 20 m/s: '); %Prompts the user to reenter a velocity within the correct range
end

g = -9.8; %Defines gravitational acceleration

projectileMotion(angle,velocity); %Calls the projectileMotion Function

    