function conditionWrite(value)
%writes value to file storage using permission 'w'
fid = fopen('condition.txt','w');
fprintf(fid,value);
fclose(fid);