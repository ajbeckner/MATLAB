function value = conditionRead()
%reads and returns value from file storage
fid = fopen('condition.txt');
value = fgetl(fid);
fclose(fid);
