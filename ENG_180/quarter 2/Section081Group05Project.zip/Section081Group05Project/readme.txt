Basically, our codes conprises a core function, a user interface, and an animation

First the user is given two options for which animation they see
The code uses a function to ask for user input and check that it is valid. This is recursive and guarantees valid input unless "cancel" is hit.

Then the code using the option generates points and factors for generating the flight path

No matter which path is chosen the code generates UFO shapes and flight paths for each. 

The UFOs spin, tilt and scale during both animations. The first shows them tilting in flight alongside one another. The second shows them crashing into larger ships, presumably post collision. Both animations feature background images and dynamic lighting to show the depth of the UFOs as well as their relative positions in space. 